package tennisstatus

type ChangeServiceSide struct {
}

func NewChangeServiceSide() ChangeServiceSide {
	return ChangeServiceSide{}
}

func (cs ChangeServiceSide) Execute() {

}
